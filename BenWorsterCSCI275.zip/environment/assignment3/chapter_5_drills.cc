#include "../std_lib_facilities.h"


int main()
try {
    //I was a litte unsure on the directions for these drills. I wasn't sure if the lines with loops actually wanted us
    //to print "Success!" that many times or just once. I made it print as many times as the origanal loop specified
    
    
    //Drill statements
    //1
    cout<<"Success!\n";
    //2
    cout<<"Success!\n";
    //3
    cout<<"Success"<<"!\n";
    //4
    cout<<"Success!"<<endl;
    //5
    int res = 7; vector<int> v(10); v[5] = res; cout<<"Success!\n";
    //6
    vector<int> v2(10); v2[5] = 7; if (v2[5] = 7) cout<<"Success!\n";
    //7
    if (2 > 1) cout<<"Success!\n"; else cout<<"Fail!\n";
    //8
    bool c = false; if (!c) cout<<"Success!\n"; else cout <<"Fail!\n";
    //9
    string s = "ape"; bool d = "fool" > s; if (d) cout<<"Success!\n";
    //10
    if (s != "fool") cout<<"Success!\n";
    //11
    if (s != "fool") cout<<"Success!\n";
    //12
    cout<<"Success!\n";
    //13
    vector<char> v3(5); for (int i = 0; i < v3.size(); ++i) cout<<"Success! "; cout<<"\n";
    //14
    vector<char> v4(5); for (int i = 0; i <= v4.size(); ++i) cout<<"Success! "; cout<<"\n";
    //15
    string s2 = "Success! "; for (int i = 0; i < 6; ++i) cout<<s2; cout<<"\n";
    //16
    if (true) cout<<"Success!\n"; else cout<<"Fail!\n";
    //17
    int x = 2000; int x2 = x; if (x2 == 2000) cout<<"Success!\n";
    //18
    string s3 = "Success! "; for (int i = 0; i < 10; ++i) cout<<s3; cout<<"\n";
    //19
    vector<char> v5(5); for (int i = 0; i < v5.size(); ++i) cout<<"Success! "; cout <<"\n";
    //20
    int a = 0; int b = 9; while (a < 10) ++a; if (b<a) cout<<"Success!\n";
    //21
    int x3 = 2; double d2 = 5; if (d2 == 2*(x3+.5)) cout<<"Success!\n";
    //22
    string s4 = "Success!\n"; cout<<s4;
    //23
    int x4 = 0; while (x4 < 10) ++x4; if (0 < x4) cout<<"Success!\n";
    //24
    cout<<"Success!\n";
    //25
    cout<<"Success!\n";
    
    
    
    
    keep_window_open();
    return 0;
}
catch (exception& e) {
    cerr<<"error: " <<e.what()<< "\n";
    keep_window_open();
    return 1;
}
catch (...) {
    cerr<<"Oops: unknown exception!\n";
    keep_window_open();
    return 2;
}