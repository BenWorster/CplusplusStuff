#include "../std_lib_facilities.h"


int main() {
    
    //variables
    int squareNumber = 1;
    int currentSquareRice = 1;
    int totalRice = 1;
      
    
    //Calculate square for 1,000 pieces of rice
    while (totalRice < 1000) {
        squareNumber++;
        currentSquareRice = currentSquareRice*2;
        totalRice = totalRice + currentSquareRice;
            
        //Print calcs every loop for debugging
        //cout<< "We are on square " <<squareNumber<< " which has " <<currentSquareRice<< " pieces of rice for " <<totalRice<< " on the chess board\n";
    }
    cout<<"For at least 1,000 pieces of rice on the board, we would need " <<squareNumber<< " squares and " <<totalRice<< " pieces of rice\n\n";
    
    
    //Calculate square for 1,000,000 pieces of rice
    while (totalRice < 1000000) {
        squareNumber++;
        currentSquareRice = currentSquareRice*2;
        totalRice = totalRice + currentSquareRice;
            
        //Print calcs every loop for debugging
        //cout<< "We are on square " <<squareNumber<< " which has " <<currentSquareRice<< " pieces of rice for " <<totalRice<< " on the chess board\n";
    }
    cout<<"For at least 1,000,000 pieces of rice on the board, we would need " <<squareNumber<< " squares and " <<totalRice<< " pieces of rice\n\n";
    
    
    //Calculate square for 1,000,000,000 pieces of rice
    while (totalRice < 1000000000) {
        squareNumber++;
        currentSquareRice = currentSquareRice*2;
        totalRice = totalRice + currentSquareRice;
            
        //Print calcs every loop for debugging
        //cout<< "We are on square " <<squareNumber<< " which has " <<currentSquareRice<< " pieces of rice for " <<totalRice<< " on the chess board\n";
    }
    cout<<"For at least 1,000,000,000 pieces of rice on the board, we would need " <<squareNumber<< " squares and " <<totalRice<< " pieces of rice\n\n";
    
    
    keep_window_open();
    return 0;
}