#include "../std_lib_facilities.h"

double ctok(double c) {
    double k = c + 273.15; //changed k from int to double
    return k; //changed int to k
}

int main() {
    double c = 0;
    cout<<"Enter a temperature in celcius to be converted to kelvin:\n";  //Added intructions and prompt for the user
    cin>>c;  //changed variable d to c
    double k = ctok(c); //remove quotes on c
    cout<<k<<endl; //lowercase c on cout
    
    
    
    keep_window_open();
    return 0;
}