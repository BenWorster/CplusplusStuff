#include "../std_lib_facilities.h"
int main()
{
    //Variables
    char answer;
    double currentNumber = 50; //This is the number that is currently part of the question the user is asked
    double previousNumber = 50; //This is the number that came before current number, unless it's the first question in which it equals currentNumber.
    int guess = 1; //This variable is used to determine how many questions have been asked
    bool guessed = false; //This is used to end the below loop
    while (guessed == false){//Loops through until user no longer wants to have their number guessed.
        cout << "Is your number less than " << currentNumber; //Prompt user using the currentNumber initialized as 50
        cin >> answer;//Read their answer either a y or n
        previousNumber = (previousNumber/2); //The previousNumber is used for the equation to narrow the answer.
        previousNumber = round(previousNumber); //Round up to prevent unreliable answer
        if (answer == 'y'){//If the number is lower than the user's number
            currentNumber = currentNumber - previousNumber;
        } else { //If the number is higher than the user's answer
            currentNumber = currentNumber + previousNumber;
        }
            guess++; //Keep track of questions
        if (guess > 7){ //Goes off only when all 7 questions have been asked
            if (answer == 'y'){ //Based on the equations of the program, if the user's last answer was yes, their number is currentNumber
            cout << "\nYour number is " << currentNumber;
            } else {//Based on the equations of the program, if the user's last answer was no their number is currentNumber minus 1
            cout << "\nYour number is " << currentNumber-1;
            }
            cout << "\nWould you like to try another number?";//Prompt the user if they would like to try again
            cin >> answer;
            if (answer == 'y'){//If they want to try again, reset variables
                currentNumber = 50;
                previousNumber = 50;
                guess = 1;
            } else {//End loop if the user does not want to continue
                guessed = true;
            }
                
        }
    }
    return 0;
}