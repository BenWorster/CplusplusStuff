#include "../std_lib_facilities.h"

int main() {
    cout <<"To get from the CSCI building to the Seawolves cafe:\n";
    cout <<"1. Leave the south end of the building and travel along Shoreway Lane until you get to the dining hall.\n";
    cout <<"2. When you reach the dinig hall, turn right onto Campus Center road.\n";
    cout <<"3. When you reach the next intersection, Seawolves cafe will be on your right.\n";
    keep_window_open();
    return 0;
}