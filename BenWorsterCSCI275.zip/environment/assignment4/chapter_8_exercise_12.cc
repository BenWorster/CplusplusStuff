#include "../std_lib_facilities.h"


//Takes in a vector and returns the min value
int vectorMin(vector<int> v){
    //variable
    int min = v[0];
    //loop to find min
    for (int i = 0; i < v.size(); i++) {
        if (v[i] < min) {
            min = v[i];
        }
    }
    return min;
}

//Takes in a vector and returns the max value
int vectorMax(vector<int> v){
    //variable
    int max = v[0];
    //loop to find min
    for (int i = 0; i < v.size(); i++) {
        if (v[i] > max) {
            max = v[i];
        }
    }
    return max;
}


//Takes in a vector and returns the mean
double vectorMean(vector<int> v){
    //variables
    int sum = 0;
    double mean;
    //loop to find sum
    for (int i = 0; i < v.size(); i++) {
        sum += v[i];
    }
    //calc mean
    mean = sum / v.size();
    return mean;
}


//Takes in a vector and returns the median
double vectorMedian(int min, int max){
    //Variable
    double median;
    //Calculate median
    median = (min + max) / 2;
    return median;
}


//main method
int main() {
    //Variables
    int min;
    int max;
    double mean;
    double median;
    vector<int> v {10, 6, 72, 44, 69, 84, 21, 35, 99};
    
    //Call functions to get stats
    min = vectorMin(v);
    max = vectorMax(v);
    mean = vectorMean(v);
    median = vectorMedian(min, max);
    
    //Print stats
    cout<<"The vector: ";
    for (int i = 0; i < v.size(); i++) {
        cout<<v[i]<<" ";
    }
    cout<<endl;
    cout<<"Min: "<<min<<"\n";
    cout<<"Max: "<<max<<"\n";
    cout<<"Mean: "<<mean<<"\n";
    cout<<"Median: "<<median<<"\n";
    
    keep_window_open();
    return 0;
}