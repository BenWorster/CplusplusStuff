#include "../std_lib_facilities.h"


void print(string label, vector<int> v) {
    
    //check vector size
    if (v.size() == 0) {
        cout<<""<<label<<":\nThe vector is empty.\n\n";
    } else {
        cout<<""<<label<<":\n";
        //loop to print vector
        for (int x : v) {
            cout<<x<<"\n";
        }
        cout<<"\n";
    }
    
}


int main() {
    
    //Variables
    string v1 = "Vector 1";
    string v2 = "Vector 2";
    string v3 = "Vector 3";
    vector<int> a;
    vector<int> b {10, 20, 30};
    vector<int> c {10, 20, 30, 40, 50, 60, 70, 80, 90, 100};
    //Call print() with each vector
    print(v1, a);
    print(v2, b);
    print(v3, c);
    
    
    
    keep_window_open();
    return 0;
}