#include "../std_lib_facilities.h"

//makes a new vector that is a reverse of the original
void reverseNew (vector<int> v) {
    //Header
    cout<<"Reversing the vector and keeping the original:\n";
    //create new vector
    vector<int> v2;
    //copy v to v2
    for (int i = 0; i < v.size(); i++){
        v2.push_back(v[i]);
    }
    //reverse v2
    reverse(v2.begin(), v2.end());
    //print both vectors
    cout << "Original Vector: "; 
    for (int i = 0; i < v.size(); i++) {
        cout<<v[i]<<" ";
    }
    cout<<endl;
    cout<<"Reversed Vector: "; 
    for (int i = 0; i < v2.size(); i++) {
        cout<<v2[i]<<" "; 
    }
    cout<<"\n\n"; 
}

//replaces the original vector with the reverse of itself
void reverseReplace (vector<int> v) {
    //Header
    cout<<"Reversing the vector and replacing the original: \n";
    //reverse vector
    reverse(v.begin(), v.end());
    //print vector
    cout<<"Reversed Vector: ";
    for (int i = 0; i < v.size(); i++) {
        cout<<v[i]<<" ";
    }
    cout<<endl;
    
}


//main method
int main() {
    //create vector
    vector<int> v {1, 3, 5, 7, 9};
    //Send vector to reversing methods
    reverseNew(v);
    reverseReplace(v);
    
    
    
    keep_window_open();
    return 0;
}