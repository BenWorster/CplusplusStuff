#ifndef LATLONPOINT_H
#define LATLONPOINT_H
class LatLonPoint
{
    private:    
        int cluster;
        double latitude;
        double longitude;
        
    public:
        LatLonPoint(){};
        LatLonPoint(double lat, double lon){
            latitude=lat;
            longitude=lon;
        };
        //make these virtual so that the derived classes can override
        virtual double getLatitude(){return latitude;};
        virtual double getLongitude(){return longitude;};
        void setCluster(int c){cluster=c;}
        int getCluster(){return cluster;}
        void setLatitude(double lat){latitude=lat;}
        void setLongitude(double lon){longitude=lon;}
};
#endif