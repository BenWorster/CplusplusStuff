//Ben Worster/Paul Smith

//CSCI275 Programming in C++

//Program designed to mimic a storee with front end and back end support
//for customers and employees



#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
using namespace std;
#include "Product.h"
//#include "kmeans.h"
//#include "LatLonPoint.h"
#include "FileIO.cc"
#include "../esj-master/json_reader.h"
#include "../esj-master/json_writer.h"


//Purchase class*************************************************************************************
class Purchase {
    
    //Properties
    private:
    string customerName;
    double latitude;
    double longitude;
    string productName;
    int timeOfDay;
    int amount;
    
    //Functions
    public:
    
    //Default constructor
    Purchase() {
        
    }
    
    //Parameterized constructor
    Purchase(string custName, double custLat, double custLon, string custProductName, int custTime, int custAmount) {
        customerName = custName;
        latitude = custLat;
        longitude = custLon;
        productName = custProductName;
        timeOfDay = custTime;
        amount = custAmount;
    }
    
    //JSON serialization method
    void serialize(JSON::Adapter& adapter)
    {
        // this pattern is required 
        JSON::Class root(adapter, "Purchase");
        //_E variant for all but last member
        JSON_E(adapter,customerName);
        JSON_E(adapter,latitude);
        JSON_E(adapter,longitude);
        JSON_E(adapter,productName);
        JSON_E(adapter,timeOfDay);
        // this is the last member variable we serialize so use the _T variant
        JSON_T(adapter,amount);
    }
    
    //get customer name method
    string getCustomerName(){
        return customerName;
    }
    
    //get latitude method
    double getLatitude() {
        return latitude;
    }
    
    //get longitude method
    double getLongitude() {
        return longitude;
    }
    
    
    
}; //End purchase class


//Customer class*************************************************************************************
class Customer {
    
    //Properties
    private:
    string username;
    double latitude;
    double longitude;
    
    //Functions
    public:
    
    //Default constructor
    Customer() {
        
    }
    
    //Parameterized constrictor
    Customer(string custName, double custLat, double custLon) {
        username = custName;
        latitude = custLat;
        longitude = custLon;
    }
    
    //Set username method
    void setUsername(string name) {
        username = name;
    }
    
    //Set latitude method
    void setLatitude(double lat) {
        latitude = lat;
    }
    
    //Set longitude method
    void setLongitude(double lon) {
        longitude = lon;
    }
    
    //Get username method
    string getUsername() {
        return username;
    }
    
    //Get latitude method
    double getLatitude() {
        return latitude;
    }
    
    //Get longitude method
    double getLongitude() {
        return longitude;
    }
    
}; //End custormer class



//Store class*******************************************************************************************
class Store {
    
    //Properties
    private:
    vector<Product*> inventory;
    Customer currentCustomer;
    vector<Purchase> purchases;
    bool activeCustomer = false;
    
    //Functions
    public:
    
    //Default constructor
    Store() {
        
    }
    
    //Parameterized
    Store(vector<Product*> inv) {
        inventory = inv;
    }
    
    //JSON serialization method
    void serialize(JSON::Adapter& adapter)
    {
        // this pattern is required 
        JSON::Class root(adapter, "Store");
        // this is the last member variable we serialize so use the _T variant
        JSON_T(adapter,purchases);
    }
    
    //show main menu method
    void showMainMenu() {
        cout<< "Enter 'E' if you are an employee\n";
        cout<< "Enter 'C' if you are a customer\n";
        cout<< "Enter 'Q' to quit\n";
        
        char mainChoice;
        cin>> mainChoice;
        
        //user picks 'e'
        if (mainChoice == 'e' || mainChoice == 'E') {
            showEmployeeMenu();
            
        //user picks 'c'    
        } else if (mainChoice == 'c' || mainChoice == 'C') {
            showCustomerMenu();
            
        //user picks 'q'
        } else if (mainChoice == 'q' || mainChoice == 'Q') {
            saveToFile();
            cout << "Goodbye!\n";
            exit(0);
            
        //user picks anything else    
        } else {
            showMainMenu();
        }
    }
    
    //customer menu method
    void showCustomerMenu() {
        //Variables
        string custName;
        //Create new customer
        if (activeCustomer == false){
        cout<<"Welcome. Please enter your name below.\n";
        cin>> custName;
        Customer* c = new Customer(custName, 0.0, 0.0);
        activeCustomer = true;
        }
        //Show customer menu
        cout<< "Enter 'P' to purchase a product\n";
        cout<< "Enter 'S' to search for a product\n";
        cout<< "Enter 'L' to list all products\n";
        cout<< "Enter ‘R’ to return to main menu\n";
        cout<< "Enter 'Q' to quit\n";
        
        //set customer choice
        char customerChoice;
        cin>> customerChoice;
        
        //user picks 'p'
        if (customerChoice == 'p' || customerChoice == 'P') {
            purchaseProduct();
            showMainMenu();
            
        //user picks 's'    
        } else if (customerChoice == 's' || customerChoice == 'S') {
            search();
            showMainMenu();
            
        //user picks 'l'  
        } else if (customerChoice == 'l' || customerChoice == 'L') {
            printAllProducts();
            showMainMenu();
            
        //user picks 'r'
        } else if (customerChoice == 'r' || customerChoice == 'R') {
            activeCustomer = false;
            showMainMenu();
            
        //user picks 'q'  
        } else if (customerChoice == 'q' || customerChoice == 'Q') {
            saveToFile();
            cout << "Goodbye!\n";
            exit(0);
            
        //user picks anything else
        } else {
            showCustomerMenu();
        }
    }
    
    //employee menu method
    void showEmployeeMenu() {
        cout<< "Enter 'A' to add a product\n";
        cout<< "Enter 'S' to search for a product\n";
        cout<< "Enter 'L' to list all products\n";
        cout<< "Enter ‘R’ to return to main menu\n";
        cout<< "Enter 'Q' to quit\n";
        
        //set employee choice
        char employeeChoice;
        cin>> employeeChoice;
        
        //user picks 'a'
        if (employeeChoice == 'a' || employeeChoice == 'A') {
            addNewProduct();
            showMainMenu();
            
        //user picks 's'    
        } else if (employeeChoice == 's' || employeeChoice == 'S') {
            search();
            showMainMenu();
            
        //user picks 'l'  
        } else if (employeeChoice == 'l' || employeeChoice == 'L') {
            printAllProducts();
            showMainMenu();
            
        //user picks 'r'
        } else if (employeeChoice == 'r' || employeeChoice == 'R') {
            showMainMenu();
            
        //user picks 'q'  
        } else if (employeeChoice == 'q' || employeeChoice == 'Q') {
            saveToFile();
            cout << "Goodbye!\n";
            exit(0);
            
        //user picks anything else
        } else {
            showEmployeeMenu();
        }
    }
    
    //purchase product method
    void purchaseProduct() {
        //variables
        string customerProduct;
        cout<<"Enter the name of the product you would like to purchase\n";
        cin>>customerProduct;
        bool invalid = true;
        bool found = false;
        int productNum = 0;
        int productCheck;
        int customerOrder;
        //Find match for product name
        for (Product* product : inventory) {
            if (product->getName() == customerProduct) {
                found = true;
                cout<<"There are " <<product->getNumInStock()<< " " <<product->getName()<< " in stock\n";
                while(invalid == true){
                    cout<<"How many would you like to order?\n";
                    cin>> customerOrder;
                    if (customerOrder < 1) {
                        showCustomerMenu();
                    }
                        productCheck = product->getNumInStock();
                        (*product)-=customerOrder;
                        inventory[productNum] = product;
                        if (productCheck != product->getNumInStock()){
                            invalid = false;
                        }
                    }
                    cout <<"Product Name: " << inventory[productNum]->getName() << "\n";
                    //cout << "Customer: " << currentCustomer.getUsername();
                addPurchase(inventory[productNum], currentCustomer, customerOrder);
                cout << "Purchase added to order!\n";
                showCustomerMenu();
        }
        productNum++;
        }
        if (found == false){
            cout<< "There is no product called " <<customerProduct<< " in our inventory.\n";
            purchaseProduct();
        }
    }
    
    //add purchase method
    void addPurchase(Product* p, Customer& c, int amount) {
        //variables
        string prodName = p->getName();
        string custName = c.getUsername();
        double lon = rand() % 100 + 1;
        double lat = rand() % 100 + 1;
        int timeOfDay = rand() % 2400;
        int custAmount = amount;
        //Create purchase
        Purchase* purchase = new Purchase(custName, lon, lat, prodName, timeOfDay, custAmount);
        purchases.push_back(Purchase(custName, lon, lat, prodName, timeOfDay, custAmount));
    }
    
    //add product that already exists method
    void addProduct(Product* p) {
        inventory.push_back(p);
    }
    
    //add new product
    void addNewProduct() {
        //variables
        string userName;
        double userCost;
        int userNumInStock;
        //Get product info from user
        cout<<"Enter the name of your product\n";
        cin >> userName;
        cout<<"Enter the cost of your product\n";
        cin >> userCost;
        cout<<"Enter the quantity of product you are adding\n";
        cin >> userNumInStock;
        //add to vector
        inventory.push_back(new Product(userName, userCost, userNumInStock));
    }
    
    //search method
    Product* search() {
        bool found = false;
        Product* p;
        cout<< "What product are you looking for?\n";
        string userSearch;
        cin>> userSearch;
        for (Product* product : inventory) {
            if (product->getName() == userSearch) {
                found = true;
                cout << "Product found\n" << product->toString();
                p = product;
            }
        }
        if (found == false) {
            cout<< "There were no matches for " << userSearch << "\n";
        }
        return p;
    }
    
    //print method
    void printAllProducts() {
        cout<< "List of all products in inventory:\n";
        for (Product* product : inventory) {
            cout << product->toString() << "\n";
        }
        cout<< "End list\n";
    }
    
    void saveToFile(){
        string fileName;
        cout << "Please enter the name of the file you'd like to save the inventory to:\n";
        cin >> fileName;
        ofstream productList {fileName};
        for (Product* product : inventory) {
            productList << product;
        }
    }

//read inventory from file
    void readFromFile() {
        //variables
        bool fileFound = false;
        string fileName;
        string productName;
        double productCost;
        int numInStock;
        //ask user for filename and checks that it was found
        while (fileFound == false) {
            cout<< "What file to do you want to read inventory from?\n";
            cin>> fileName;
            if (fileName == "products.txt") {
                fileFound = true;
            } else {
                cout<<"No file named " << fileName << " was found\n";
            }
        }
        //declare ifstream
        ifstream file;
        //open file
        file.open(fileName.c_str());
        //while there is still stuff to read
        while (file>>productName>>productCost>>numInStock) {
            inventory.push_back(new Product(productName, productCost, numInStock));
        }
        file.close();
    }
    //Deconstructor
    ~Store(){
        inventory.clear();
        purchases.clear();
    }
}; //End Store Class



//Product class*****************************************************************************************
    
//Default constructor
Product::Product() {
        
   }
    
//Parameterized contructor
Product::Product(string theName, double theCost, int theNumInStock) {
    name = theName;
    cost = theCost;
    numInStock = theNumInStock;
}

Product& Product:: operator-=(int amount){
        try{
            
            if (this->numInStock - amount < 0){
                throw amount;
            } else {
                this->numInStock -= amount;
            }
            
        } catch (int e){
            cout << "invalid_argument Exception: There are only " << this->numInStock << " left in stock. You attempted to order " << e << "\n";
        }
        
}

ostream& operator<<(ostream& os, const Product& p){
    Product product = p;
    os << product.getName() << " " << product.getCost() << " " << product.getNumInStock() << endl;
}

istream& operator>> (istream& is, Product& p) {
    Product product = p;
    string name;
    double cost;
    int stock;
    is >> name >> cost >> stock;
    product.setName(name);
    product.setCost(cost);
    product.setNumInStock(stock);
}

//Set name method
void Product::setName(string n) {
    name = n;
}
    
//Set cost method
void Product::setCost(double c) {
    cost = c;
}
    
//Set numInStock method
void Product::setNumInStock(int n) {
    numInStock = n;
}
    
//Get name method
string Product::getName() {
    return name;
}
    
//Get cost method
double Product::getCost() {
    return cost;
}
    
//Get numnStock method
int Product::getNumInStock() {
    return numInStock;
}
    
//toString method
string Product::toString() {
    ostringstream s;
    s<< "Product name: " << name << "\nProduct cost: $" << cost << "\nNumber in stock: " << numInStock <<"\n";
    return s.str();
}
    
//main method
int main() {
    
    //Store json file to string
    string file = readFileAsString("store.json");
    
    //print for debugging
    //cout << file;
        
    //create inventory
    vector<Product*> myInventory;
    Store myStore(myInventory);
    string json = JSON::producer<Store>::convert(myStore);
    myStore = JSON::consumer<Store>::convert(json);
    myStore.readFromFile();

        
    //call main menu
    myStore.showMainMenu();
    string jsonOut= JSON::producer<Store>::convert(myStore);
    writeStringToFile("purchases.txt",jsonOut);
    
//keep_window_open();
return 0;
}
    
 //End product class