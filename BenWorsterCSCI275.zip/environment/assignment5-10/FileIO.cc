
#include <iostream>
#include <fstream>
#include <sstream>

using namespace std;
/****  read file into a string one character at a time
 * ****/
string readFileAsString(string iName)
{
    ostringstream oss;
    ifstream ist {iName};	// ifstream is an“input stream from a file”
				// defining an ifstream with a name string
				// opens the file of that name for reading
	if (!ist)
	{
	    cout << "can’t open input file " << iName;
	    return "";
	}
	string fileContents;
	while(getline(ist, fileContents)) //use getline so it retrieves spaces
	{
	
	    oss << fileContents << endl;
	}
	
	return oss.str();
	
}

void writeStringToFile(string oName, string contents)
{
	ofstream ost {oName};
	if(!ost)
	{
		cout << "Can't open output file "<< oName;
		return;
	}
	ost << contents;
}