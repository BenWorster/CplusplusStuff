#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
#ifndef KMEANS_H
#define KMEANS_H
class Kmeans{
    public:
        Kmeans(){k=3;};
        Kmeans(int kv);
        double computeDistance(double lat1, double lon1, double lat2, double lon2);
        double computeDistance(LatLonPoint *p1, LatLonPoint *p2);
        void addPoint(LatLonPoint *p);
        void initializeMeans();
        void printMeans();
        void runClusterer(); 

    private:
        vector<LatLonPoint*> points; //this needs to be a pointer to prevent copying.
        int k;
        vector<LatLonPoint*> means;
        int updateClusters();//returns the number of points which changed clusters
        void updateMeans();
};
#endif