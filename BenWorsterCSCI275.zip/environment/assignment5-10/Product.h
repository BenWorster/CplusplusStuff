#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
using namespace std;

//Product class
class Product {
    
    //Properties
    private:
    string name;
    string description;
    double cost;
    int numInStock;
    
    //Functions
    public:
    
    //Default constructor
    Product();
    
    //Parameterized contructor
    Product(string theName, double theCost, int theNumInStock);
    
    //Product operator function
    Product& operator-=(int amount);
    
    //ostream operator
    friend ostream& operator<<(ostream& os, const Product& p);
    
    //istream operator
    friend istream& operator>> (istream& is, Product& p);
     
    //Set name method
    void setName(string n);
    
    //Set description method
    void setDescription(string d);
    
    //Set cost method
    void setCost(double c);
    
    //Set numInStock method
    void setNumInStock(int n);
    
    //Get name method
    string getName();
    
    //Get description method
    string getDescription();
    
    //Get cost method
    double getCost();
    
    //Get numnStock method
    int getNumInStock();
    
    //toString method
    string toString();
    
    
};