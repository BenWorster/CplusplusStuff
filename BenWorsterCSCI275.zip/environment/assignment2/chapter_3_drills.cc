#include "../std_lib_facilities.h"


int main() {
    //Drill 1
    cout<<"Enter the name of the person you want to write to:\n";
    string first_name;
    cin>>first_name;
    cout<<"Dear " <<first_name<< ",\n";
    //Drill 2
    cout<<"\tHow are you doing? I've been good, just really busy. Text me sometime Ms G and lets chill.\n\n";
    //Drill 3
    cout<<"Enter the name of your other friend:\n";
    string friend_name;
    cin>> friend_name;
    cout<<"Have you seen " <<friend_name<< " lately?\n";
    //Drill 4
    cout<<"What sex is your friend? (m for male, f for female)\n";
    char friend_sex;
    cin>>friend_sex;
    if (friend_sex == 'm') {
        cout<<"If you see " <<friend_name<< " ask him to call me.\n";
    } 
    if (friend_sex == 'f') {
        cout<<"If you see " <<friend_name<< " ask her to call me.\n";
    }
    
    
    keep_window_open();
    return 0;
}