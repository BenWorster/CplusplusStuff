#include "../std_lib_facilities.h"


int main() {
    //Instuctions and user input
    cout<<"Please enter the two integers you want to perform operations on:\n";
    int var1;
    int var2;
    cin>>var1>>var2;
    cout<<"The operations on " <<var1<< " and " <<var2<< " are:\n";
    //Calc min/max
    int min;
    int max;
    if (var1 > var2) {
        max = var1;
        min = var2;
    } else {
        min = var1;
        max = var2;
    }
    //Calc sum
    int sum = var1 + var2;
    //Calc diff
    int difference = max - min;
    //Calc product
    int product = var1 * var2;
    //Calc quotient
    int quotient = max / min;
    //Print calculation
    cout<<"Smallest: " <<min<<"\n";
    cout<<"Largest: " <<max<<"\n";
    cout<<"Sum: " <<sum<<"\n";
    cout<<"Difference: " <<difference<<"\n";
    cout<<"Product: " <<product<<"\n";
    cout<<"Quotient: " <<quotient<<"\n";
    
    
    keep_window_open();
    return 0;
}