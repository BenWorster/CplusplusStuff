#include "../std_lib_facilities.h"


int main() {
    //Instuctions and user input
    cout<<"Please enter the two floating point number you want to perform operations on:\n";
    double var1;
    double var2;
    cin>>var1>>var2;
    cout<<"The operations on " <<var1<< " and " <<var2<< " are:\n";
    //Calc min/max
    double min;
    double max;
    if (var1 > var2) {
        max = var1;
        min = var2;
    } else {
        min = var1;
        max = var2;
    }
    //Calc sum
    double sum = var1 + var2;
    //Calc diff
    double difference = max - min;
    //Calc product
    double product = var1 * var2;
    //Calc quotient
    double quotient = max / min;
    //Print calculation
    cout<<"Smallest: " <<min<<"\n";
    cout<<"Largest: " <<max<<"\n";
    cout<<"Sum: " <<sum<<"\n";
    cout<<"Difference: " <<difference<<"\n";
    cout<<"Product: " <<product<<"\n";
    cout<<"Quotient: " <<quotient<<"\n";
    
    
    keep_window_open();
    return 0;
}