#include "../std_lib_facilities.h"


int main() {
    //Instuctions and user input
    cout<<"Enter an integer to see if it is odd or even:\n";
    int userInput;
    cin>> userInput;
    //Determine odd or even
    if (userInput % 2 == 0){
        cout<<"" <<userInput<< " is and even number.\n";
    } else {
        cout<<"" <<userInput<< " is an odd number.\n";
    }
    
    
    
    keep_window_open();
    return 0;
}